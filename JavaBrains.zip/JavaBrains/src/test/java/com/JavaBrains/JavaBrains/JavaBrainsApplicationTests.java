package com.JavaBrains.JavaBrains;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaBrainsApplicationTests {

	@Test
	void contextLoads() {
	}

}
